// ADR 006 #3↔#4 glue — Solar's mount() reads the `__ZAB_PEER_VIEWER__` page
// global the Prism scene-server pins (FINAL MODEL : multi-room `{ rooms: [...] }`),
// joins EVERY room as a viewer, and threads the aggregated peer-stream resolvers
// into the runtime so LIVE `media` nodes render the matching peer's stream. The
// runtime is mocked so the test asserts the WIRING (injection pass-through,
// resolver threading, teardown) without a real WS.

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  readPeerViewerInjection,
  ZAB_LSDP_PEER_VIEWER_GLOBAL,
  ZAB_PEER_VIEWER_GLOBAL,
} from "../../src/peer-viewer/injection";

const {
  mountRuntime,
  createPeerViewerFromInjection,
  resolvePeerStream,
  subscribePeerStream,
  registryResolve,
  registryOrderedLabels,
  join,
  leave,
} = vi.hoisted(() => {
  const resolvePeerStream = vi.fn(() => null);
  const subscribePeerStream = vi.fn(() => () => undefined);
  // A minimal `peer_label`-keyed registry the slot-binding view wraps on BOTH
  // the preview and the antenne paths. `registryResolve` / `registryOrderedLabels`
  // let a test assert bare peer_label pass-through AND positional `@<n>`
  // resolution without a real WebRTC stack.
  const registryResolve = vi.fn((_peerLabel: string): unknown => null);
  const registryOrderedLabels = vi.fn((): string[] => []);
  const join = vi.fn(() => Promise.resolve());
  const leave = vi.fn();
  return {
    mountRuntime: vi.fn(() => ({ disconnect: vi.fn(), setToken: vi.fn() })),
    createPeerViewerFromInjection: vi.fn(() => ({
      join,
      leave,
      resolvePeerStream,
      subscribePeerStream,
      setRooms: vi.fn(() => Promise.resolve()),
      registry: {
        resolve: registryResolve,
        orderedLabels: registryOrderedLabels,
        subscribeRoster: vi.fn(() => () => undefined),
        subscribe: vi.fn((_l: string, cb: (s: unknown) => void) => {
          cb(null);
          return () => undefined;
        }),
        set: vi.fn(),
        remove: vi.fn(),
        clear: vi.fn(),
      },
    })),
    resolvePeerStream,
    subscribePeerStream,
    registryResolve,
    registryOrderedLabels,
    join,
    leave,
  };
});

vi.mock("@lumencast/runtime", () => ({
  mount: mountRuntime,
  createPeerViewerFromInjection,
}));

// Imported AFTER the mock is registered.
import { mount } from "../../src/mount";
import type { MountOptions } from "../../src/index";

const PEER_GLOBAL = "__ZAB_PEER_VIEWER__";
const CHANNEL_GLOBAL = "__ZAB_PEER_VIEWER_CHANNEL__";
const LSDP_GLOBAL = "__ZAB_LSDP_PEER_VIEWER__";
const CAPTURE_GLOBAL = "__ZAB_CAPTURE_DEVICES__";

function baseOptions(over: Partial<MountOptions> = {}): MountOptions {
  return {
    target: document.createElement("div"),
    orionUrl: "ws://127.0.0.1:4007/orion/api/v1/show/stream",
    token: "fake-token",
    mode: "broadcast",
    ...over,
  };
}

/** Read the options the (mocked) runtime mount was called with — guarded so a
 *  zero-call situation fails with a clear message instead of a tuple error. */
function runtimeOptsOf(): Record<string, unknown> {
  const calls = mountRuntime.mock.calls as unknown as unknown[][];
  expect(calls.length).toBeGreaterThan(0);
  const first = calls[0] ?? [];
  return first[0] as Record<string, unknown>;
}

afterEach(() => {
  vi.clearAllMocks();
  delete (globalThis as Record<string, unknown>)[PEER_GLOBAL];
  delete (globalThis as Record<string, unknown>)[CHANNEL_GLOBAL];
  delete (globalThis as Record<string, unknown>)[LSDP_GLOBAL];
  delete (globalThis as Record<string, unknown>)[CAPTURE_GLOBAL];
});

beforeEach(() => {
  delete (globalThis as Record<string, unknown>)[PEER_GLOBAL];
  delete (globalThis as Record<string, unknown>)[CHANNEL_GLOBAL];
  delete (globalThis as Record<string, unknown>)[LSDP_GLOBAL];
  delete (globalThis as Record<string, unknown>)[CAPTURE_GLOBAL];
});

describe("peer-viewer glue (multi-room)", () => {
  it.each(["preview", "generation"])(
    "uses the same channel resolver on the %s wire for late rooms, manual routing and automatic reset",
    async (wire) => {
      class Channel extends EventTarget {
        static current: Channel;
        readyState = 1;
        send = vi.fn();
        constructor() {
          super();
          Channel.current = this;
        }
        close() {}
        push(state: unknown) {
          this.dispatchEvent(
            new MessageEvent("message", {
              data: JSON.stringify({ type: "peer_viewer", state }),
            }),
          );
        }
      }
      vi.stubGlobal("WebSocket", Channel);
      (globalThis as Record<string, unknown>)[CHANNEL_GLOBAL] = {
        url: "ws://127.0.0.1:43123/preview/peer-viewer?token=fixture",
      };
      const handle = mount(
        baseOptions({
          orionUrl: `ws://127.0.0.1:4317/api/v1/show/${wire}.lsdp`,
        }),
      );
      const resolve = runtimeOptsOf().resolvePeerStream as (
        ref: string,
      ) => unknown;
      const rooms = [
        {
          signalingUrl: "wss://example.test/ws",
          roomId: "room",
          token: "private-fixture",
        },
      ];
      registryOrderedLabels.mockReturnValue(["Alex", "Sam"]);
      registryResolve.mockImplementation((label) =>
        label === "Alex"
          ? { id: "alex-stream" }
          : label === "Sam"
            ? { id: "sam-stream" }
            : null,
      );
      Channel.current.push({
        rooms,
        slots: {},
        slotRefs: ["@0"],
        routingRevision: 1,
      });
      await vi.waitFor(() => expect(Channel.current.send).toHaveBeenCalled());
      expect(resolve("@0")).toEqual({ id: "alex-stream" });
      expect(
        JSON.parse(Channel.current.send.mock.calls.at(-1)![0]),
      ).toMatchObject({
        type: "peer_viewer_routing",
        revision: 1,
        slots: { "@0": { peerLabel: "Alex", available: true } },
      });
      Channel.current.push({
        rooms,
        slots: { "@0": "Sam" },
        slotRefs: ["@0"],
        routingRevision: 2,
      });
      await vi.waitFor(() =>
        expect(resolve("@0")).toEqual({ id: "sam-stream" }),
      );
      Channel.current.push({
        rooms,
        slots: {},
        slotRefs: ["@0"],
        routingRevision: 3,
      });
      await vi.waitFor(() =>
        expect(resolve("@0")).toEqual({ id: "alex-stream" }),
      );
      expect(JSON.stringify(Channel.current.send.mock.calls)).not.toContain(
        "private-fixture",
      );
      handle.disconnect();
      vi.unstubAllGlobals();
      registryResolve.mockReset().mockReturnValue(null);
      registryOrderedLabels.mockReset().mockReturnValue([]);
    },
  );
  it("passes a multi-room global straight through and threads the resolvers", () => {
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "meet-a",
          token: "tok-a",
        },
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "meet-b",
          token: "tok-b",
        },
      ],
    };

    mount(baseOptions());

    expect(createPeerViewerFromInjection).toHaveBeenCalledTimes(1);
    expect(createPeerViewerFromInjection).toHaveBeenCalledWith({
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "meet-a",
          token: "tok-a",
        },
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "meet-b",
          token: "tok-b",
        },
      ],
    });
    expect(join).toHaveBeenCalledTimes(1);

    const runtimeOpts = runtimeOptsOf();
    // PREVIEW is now slot-aware (parity with the antenne): the threaded resolver
    // is the slot-binding wrapper, not the raw viewer fn. A bare peer_label still
    // passes straight through to the registry.
    expect(runtimeOpts.resolvePeerStream).not.toBe(resolvePeerStream);
    (runtimeOpts.resolvePeerStream as (k: string) => unknown)("alice");
    expect(registryResolve).toHaveBeenCalledWith("alice");
  });

  it("wraps a legacy single-room global as a one-room array (back-compat)", () => {
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      signalingUrl: "wss://meet.example/ws",
      roomId: "meet-xyz",
      token: "room-tok",
    };

    mount(baseOptions());

    expect(createPeerViewerFromInjection).toHaveBeenCalledTimes(1);
    expect(createPeerViewerFromInjection).toHaveBeenCalledWith({
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "meet-xyz",
          token: "room-tok",
        },
      ],
    });
  });

  it("drops malformed rooms and keeps usable ones", () => {
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      rooms: [
        { signalingUrl: "wss://meet.example/ws", token: "no-room-id" },
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "meet-ok",
          token: "tok-ok",
        },
      ],
    };

    mount(baseOptions());

    expect(createPeerViewerFromInjection).toHaveBeenCalledWith({
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "meet-ok",
          token: "tok-ok",
        },
      ],
    });
  });

  it("does NOT create a viewer at mount when the global is absent (antenne)", () => {
    mount(baseOptions());
    // No mount-time creds → no viewer yet, but the antenne controller's slot-aware
    // resolvers + the reserved-leaf hook ARE threaded so the runtime can light the
    // `x-zab.meet-peer` path up once Orion's LSDP delivers the creds.
    expect(createPeerViewerFromInjection).not.toHaveBeenCalled();
    const runtimeOpts = runtimeOptsOf();
    expect(typeof runtimeOpts.resolvePeerStream).toBe("function");
    expect(typeof runtimeOpts.subscribePeerStream).toBe("function");
    expect(typeof runtimeOpts.onReservedLeaves).toBe("function");
  });

  it("does NOT create a viewer when rooms is present but all malformed", () => {
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      rooms: [{ signalingUrl: "wss://meet.example/ws", token: "no-room-id" }],
    };
    mount(baseOptions());
    expect(createPeerViewerFromInjection).not.toHaveBeenCalled();
  });

  it("ignores a malformed single-room global (missing roomId)", () => {
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      signalingUrl: "wss://meet.example/ws",
      token: "room-tok",
    };
    mount(baseOptions());
    expect(createPeerViewerFromInjection).not.toHaveBeenCalled();
  });

  it("tears the viewer down on disconnect", () => {
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "meet-xyz",
          token: "room-tok",
        },
      ],
    };
    const handle = mount(baseOptions());
    handle.disconnect();
    expect(leave).toHaveBeenCalledTimes(1);
  });

  it("delegates same-room credential rotation to the seamless runtime handoff", async () => {
    class PreviewChannelSocket extends EventTarget {
      static instance: PreviewChannelSocket | null = null;
      readonly readyState = 1;

      constructor(readonly url: string) {
        super();
        PreviewChannelSocket.instance = this;
      }

      close(): void {
        this.dispatchEvent(new Event("close"));
      }

      push(value: unknown): void {
        this.dispatchEvent(
          new MessageEvent("message", { data: JSON.stringify(value) }),
        );
      }
    }

    const viewer = {
      join,
      leave: vi.fn(),
      resolvePeerStream,
      subscribePeerStream,
      setRooms: vi.fn(() => Promise.resolve()),
      registry: {
        resolve: registryResolve,
        orderedLabels: registryOrderedLabels,
        subscribeRoster: vi.fn(() => () => undefined),
        subscribe: vi.fn(() => () => undefined),
        set: vi.fn(),
        remove: vi.fn(),
        clear: vi.fn(),
      },
    };
    createPeerViewerFromInjection.mockReturnValueOnce(viewer);
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "stable-room",
          token: "token-a",
        },
      ],
    };
    (globalThis as Record<string, unknown>)[CHANNEL_GLOBAL] = {
      url: "ws://127.0.0.1:43123/preview/peer-viewer?token=local",
    };
    vi.stubGlobal(
      "WebSocket",
      PreviewChannelSocket as unknown as typeof WebSocket,
    );

    mount(baseOptions());
    PreviewChannelSocket.instance?.push({
      type: "peer_viewer",
      state: {
        rooms: [
          {
            signalingUrl: "wss://meet.example/ws",
            roomId: "stable-room",
            token: "token-b",
          },
        ],
        slots: {},
      },
    });
    await Promise.resolve();
    await Promise.resolve();

    // The runtime fingerprints room credentials and keeps the old generation
    // alive until the replacement has delivered its first track. Calling
    // leave() here would blank Preview and the local live browser_source.
    expect(viewer.leave).not.toHaveBeenCalled();
    expect(viewer.setRooms).toHaveBeenCalledWith([
      {
        signalingUrl: "wss://meet.example/ws",
        roomId: "stable-room",
        token: "token-b",
      },
    ]);
  });

  it("wires preview subscriptions, token updates, and the unload teardown", () => {
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "meet-unload",
          token: "room-tok",
        },
      ],
    };
    const add = vi.spyOn(window, "addEventListener");
    const handle = mount(baseOptions());
    const runtimeOpts = runtimeOptsOf();
    const off = (
      runtimeOpts.subscribePeerStream as (
        key: string,
        listener: (s: MediaStream | null) => void,
      ) => () => void
    )("alice", vi.fn());
    off();
    handle.setToken("next-token");

    const unload = add.mock.calls.find(
      ([type]) => type === "beforeunload",
    )?.[1];
    expect(typeof unload).toBe("function");
    (unload as EventListener)(new Event("beforeunload"));
    expect(leave).toHaveBeenCalled();
    add.mockRestore();
  });

  it("threads SLOT-AWARE resolvers on the preview path (positional @<n>)", () => {
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "meet-a",
          token: "tok-a",
        },
      ],
    };
    mount(baseOptions());
    const runtimeOpts = runtimeOptsOf();
    // The preview wraps the raw registry with the slot-binding so a positional
    // `@0` resolves to the first-arrived peer (auto-fill) and a bare peer_label
    // passes through. (Was ANTENNE-only before → the preview cam stayed empty
    // even with the stream received.)
    const stream = {} as MediaStream;
    registryOrderedLabels.mockReturnValue(["alice"]);
    registryResolve.mockImplementation((l: string) =>
      l === "alice" ? stream : null,
    );
    const resolve = runtimeOpts.resolvePeerStream as (k: string) => unknown;
    expect(resolve("@0")).toBe(stream);
    expect(resolve("bob")).toBe(null);
    expect(registryResolve).toHaveBeenCalledWith("bob");
  });

  it("uses the pinned preview slot snapshot instead of WebRTC arrival order", () => {
    const stream = {} as MediaStream;
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "meet-a",
          token: "tok-a",
        },
      ],
      slots: {
        "@0": "invite-1",
        "@1": "invite-2",
        "@2": "invite-3",
      },
    };
    // No arrival roster is available yet. The scene slot must nevertheless be
    // wired to its authored peer so the first remote-track notification reaches
    // the correct LivePeerVideo consumer.
    registryOrderedLabels.mockReturnValue([]);
    registryResolve.mockImplementation((label: string) =>
      label === "invite-3" ? stream : null,
    );

    mount(baseOptions());

    const resolve = runtimeOptsOf().resolvePeerStream as (
      key: string,
    ) => unknown;
    expect(resolve("@2")).toBe(stream);
    expect(registryResolve).toHaveBeenCalledWith("invite-3");
  });

  it("surfaces a join failure through onError without throwing", async () => {
    join.mockRejectedValueOnce(new Error("ws handshake failed"));
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "meet-xyz",
          token: "room-tok",
        },
      ],
    };
    const onError = vi.fn();
    expect(() => mount(baseOptions({ onError }))).not.toThrow();
    // Let the rejected join microtask settle.
    await Promise.resolve();
    await Promise.resolve();
    expect(onError).toHaveBeenCalledWith(
      expect.objectContaining({ code: "INTERNAL", recoverable: true }),
    );
  });

  it("stringifies a non-Error join rejection at the Solar boundary", async () => {
    join.mockRejectedValueOnce("ws handshake failed");
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "meet-string-error",
          token: "room-tok",
        },
      ],
    };
    const onError = vi.fn();
    mount(baseOptions({ onError }));
    await Promise.resolve();
    await Promise.resolve();

    expect(onError).toHaveBeenCalledWith(
      expect.objectContaining({
        message: "peer-viewer join failed: ws handshake failed",
      }),
    );
  });
});

describe("peer-viewer glue — second LSDP source + slotRef re-keying (antenne)", () => {
  it("reads viewer creds from the LSDP global without Prism (antenne)", () => {
    (globalThis as Record<string, unknown>)[LSDP_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "antenne-a",
          token: "lsdp-tok",
        },
      ],
    };
    mount(baseOptions());
    expect(createPeerViewerFromInjection).toHaveBeenCalledWith({
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "antenne-a",
          token: "lsdp-tok",
        },
      ],
    });
  });

  it("threads the SLOT-AWARE resolvers when the LSDP source is present", () => {
    (globalThis as Record<string, unknown>)[LSDP_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "antenne-a",
          token: "lsdp-tok",
        },
      ],
    };
    mount(baseOptions());
    const runtimeOpts = runtimeOptsOf();
    // The wrapper, NOT the raw viewer resolver identity.
    expect(runtimeOpts.resolvePeerStream).not.toBe(resolvePeerStream);
    expect(typeof runtimeOpts.resolvePeerStream).toBe("function");
    expect(typeof runtimeOpts.subscribePeerStream).toBe("function");
  });

  it("resolves slotRef → peer_label → track via the LSDP slot snapshot", () => {
    const cam = { id: "cam-1" } as unknown as MediaStream;
    registryResolve.mockImplementation((label: string) =>
      label === "alice" ? cam : null,
    );
    (globalThis as Record<string, unknown>)[LSDP_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "antenne-a",
          token: "lsdp-tok",
        },
      ],
      slots: { "cam-caster-1": "alice" },
    };
    mount(baseOptions());
    const resolve = runtimeOptsOf().resolvePeerStream as (k: string) => unknown;
    // The runtime hands the node's slotRef ; the wrapper translates to peer_label.
    expect(resolve("cam-caster-1")).toBe(cam);
    expect(registryResolve).toHaveBeenCalledWith("alice");
  });

  it("renders the placeholder (null) for an unbound slot", () => {
    registryResolve.mockReturnValue(null);
    (globalThis as Record<string, unknown>)[LSDP_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "antenne-a",
          token: "lsdp-tok",
        },
      ],
    };
    mount(baseOptions());
    const resolve = runtimeOptsOf().resolvePeerStream as (k: string) => unknown;
    expect(resolve("cam-unbound")).toBeNull();
  });

  it("merges preview + LSDP rooms and de-dups by roomId", () => {
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "shared",
          token: "preview-tok",
        },
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "preview-only",
          token: "p-tok",
        },
      ],
    };
    (globalThis as Record<string, unknown>)[LSDP_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "shared",
          token: "lsdp-tok",
        },
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "antenne-only",
          token: "a-tok",
        },
      ],
    };
    mount(baseOptions());
    expect(createPeerViewerFromInjection).toHaveBeenCalledWith({
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "shared",
          token: "preview-tok",
        },
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "preview-only",
          token: "p-tok",
        },
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "antenne-only",
          token: "a-tok",
        },
      ],
    });
  });

  it("keeps a local Orion document on the Prism path when LSDP also exists", () => {
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "preview-room",
          token: "preview-token",
        },
      ],
    };
    (globalThis as Record<string, unknown>)[LSDP_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "antenne-room",
          token: "antenne-token",
        },
      ],
      slots: { "cam-0": "alice" },
    };

    mount(baseOptions());

    // A local Program browser_source must use the same Prism viewer/channel
    // as Preview; a stale LSDP leaf must not divert it to the async Antenne
    // controller and leave the live Meet tracks black.
    expect(createPeerViewerFromInjection).toHaveBeenCalledWith({
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "preview-room",
          token: "preview-token",
        },
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "antenne-room",
          token: "antenne-token",
        },
      ],
    });
    expect(runtimeOptsOf().onReservedLeaves).toBeUndefined();
  });

  it("merges preview slot bindings and lets LSDP override the live slot", () => {
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "preview",
          token: "p-tok",
        },
      ],
      slots: {
        "cam-0": "preview-peer",
        "cam-1": "preview-only",
      },
    };
    (globalThis as Record<string, unknown>)[LSDP_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "live",
          token: "a-tok",
        },
      ],
      slots: { "cam-0": "live-peer" },
    };

    expect(readPeerViewerInjection().slotBindings).toEqual({
      "cam-0": "live-peer",
      "cam-1": "preview-only",
    });
  });

  it("ignores a malformed LSDP global (no usable room)", () => {
    (globalThis as Record<string, unknown>)[LSDP_GLOBAL] = {
      rooms: [{ signalingUrl: "wss://meet.example/ws", token: "no-room-id" }],
    };
    mount(baseOptions());
    expect(createPeerViewerFromInjection).not.toHaveBeenCalled();
  });

  it("accepts a legacy room object even when it carries a non-array rooms field", () => {
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      rooms: "legacy-marker",
      signalingUrl: "wss://meet.example/ws",
      roomId: "legacy-with-marker",
      token: "room-tok",
    };
    mount(baseOptions());

    expect(createPeerViewerFromInjection).toHaveBeenCalledWith({
      rooms: [
        {
          rooms: "legacy-marker",
          signalingUrl: "wss://meet.example/ws",
          roomId: "legacy-with-marker",
          token: "room-tok",
        },
      ],
    });
  });

  it("takes the defensive legacy path when rooms is not an array", () => {
    (globalThis as Record<string, unknown>)[ZAB_PEER_VIEWER_GLOBAL] = {
      rooms: "not-an-array",
      signalingUrl: "wss://meet.example/ws",
      roomId: "legacy-direct",
      token: "room-tok",
    };

    expect(readPeerViewerInjection().injection).toEqual({
      rooms: [
        {
          rooms: "not-an-array",
          signalingUrl: "wss://meet.example/ws",
          roomId: "legacy-direct",
          token: "room-tok",
        },
      ],
    });

    (globalThis as Record<string, unknown>)[ZAB_LSDP_PEER_VIEWER_GLOBAL] = {
      slots: {
        "cam-valid": "alice",
        "cam-empty": "",
        "cam-malformed": 42,
      },
    };
    expect(readPeerViewerInjection().slotBindings).toEqual({
      "cam-valid": "alice",
    });
  });
});

describe("peer-viewer glue — runtime onReservedLeaves hook (antenne, 0.11.0)", () => {
  /** Pull the reserved-leaf sink the (mocked) runtime mount was handed. */
  function hookOf(): (leaves: {
    viewer?: unknown;
    slots: Record<string, string>;
  }) => void {
    const fn = runtimeOptsOf().onReservedLeaves;
    expect(typeof fn).toBe("function");
    return fn as (leaves: {
      viewer?: unknown;
      slots: Record<string, string>;
    }) => void;
  }

  it("arms the receive-only viewer from leaves.viewer (no mount-time global)", () => {
    mount(baseOptions());
    expect(createPeerViewerFromInjection).not.toHaveBeenCalled();

    hookOf()({
      viewer: {
        rooms: [
          {
            signalingUrl: "wss://meet.example/ws",
            roomId: "antenne-a",
            token: "lsdp-tok",
          },
        ],
      },
      slots: {},
    });

    // The hook arms the viewer + joins RECEIVE-ONLY (never publishes).
    expect(createPeerViewerFromInjection).toHaveBeenCalledWith({
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "antenne-a",
          token: "lsdp-tok",
        },
      ],
    });
    expect(join).toHaveBeenCalledTimes(1);
  });

  it("resolves slotRef → peer_label → track once armed by the hook", () => {
    const cam = { id: "cam-1" } as unknown as MediaStream;
    registryResolve.mockImplementation((label: string) =>
      label === "alice" ? cam : null,
    );
    mount(baseOptions());

    hookOf()({
      viewer: {
        rooms: [
          {
            signalingUrl: "wss://meet.example/ws",
            roomId: "antenne-a",
            token: "lsdp-tok",
          },
        ],
      },
      slots: { "cam-caster-1": "alice" },
    });

    const resolve = runtimeOptsOf().resolvePeerStream as (k: string) => unknown;
    expect(resolve("cam-caster-1")).toBe(cam);
    expect(registryResolve).toHaveBeenCalledWith("alice");
    // An unbound slot → placeholder (null), never the wrong cam.
    expect(resolve("cam-unbound")).toBeNull();
  });

  it("reconciles the snapshot : a slot dropped from leaves.slots is released", () => {
    const cam = { id: "cam-1" } as unknown as MediaStream;
    registryResolve.mockImplementation((label: string) =>
      label === "alice" ? cam : null,
    );
    mount(baseOptions());
    const hook = hookOf();

    hook({
      viewer: {
        rooms: [
          {
            signalingUrl: "wss://meet.example/ws",
            roomId: "antenne-a",
            token: "lsdp-tok",
          },
        ],
      },
      slots: { "cam-caster-1": "alice" },
    });
    const resolve = runtimeOptsOf().resolvePeerStream as (k: string) => unknown;
    expect(resolve("cam-caster-1")).toBe(cam);

    // Newer snapshot no longer carries cam-caster-1 → it must unbind (placeholder).
    hook({ slots: {} });
    expect(resolve("cam-caster-1")).toBeNull();
  });

  it("reconciles the live room set on a later emission via setRooms", () => {
    const viewer = {
      join,
      leave,
      resolvePeerStream,
      subscribePeerStream,
      setRooms: vi.fn(() => Promise.resolve()),
      registry: {
        resolve: registryResolve,
        orderedLabels: registryOrderedLabels,
        subscribeRoster: vi.fn(() => () => undefined),
        subscribe: vi.fn(() => () => undefined),
        set: vi.fn(),
        remove: vi.fn(),
        clear: vi.fn(),
      },
    };
    createPeerViewerFromInjection.mockReturnValueOnce(viewer);
    mount(baseOptions());
    const hook = hookOf();

    hook({
      viewer: {
        rooms: [
          { signalingUrl: "wss://meet.example/ws", roomId: "a", token: "t1" },
        ],
      },
      slots: {},
    });
    expect(createPeerViewerFromInjection).toHaveBeenCalledTimes(1);

    hook({
      viewer: {
        rooms: [
          { signalingUrl: "wss://meet.example/ws", roomId: "b", token: "t2" },
        ],
      },
      slots: {},
    });
    // A second viewer is NOT created — the existing one reconciles its room set.
    expect(createPeerViewerFromInjection).toHaveBeenCalledTimes(1);
    expect(viewer.setRooms).toHaveBeenCalledWith([
      { signalingUrl: "wss://meet.example/ws", roomId: "b", token: "t2" },
    ]);
  });

  it("does nothing for a leaves emission with no usable viewer creds", () => {
    mount(baseOptions());
    hookOf()({ slots: { "cam-caster-1": "alice" } });
    // Slots without creds can't arm the viewer — stays inert until creds arrive.
    expect(createPeerViewerFromInjection).not.toHaveBeenCalled();
  });

  it("does nothing when the viewer leaf has an empty rooms array", () => {
    mount(baseOptions());
    hookOf()({ viewer: { rooms: [] }, slots: {} });
    expect(createPeerViewerFromInjection).not.toHaveBeenCalled();
  });

  it("is NOT registered on the preview path (frozen)", () => {
    (globalThis as Record<string, unknown>)[PEER_GLOBAL] = {
      rooms: [
        {
          signalingUrl: "wss://meet.example/ws",
          roomId: "meet-a",
          token: "tok-a",
        },
      ],
    };
    mount(baseOptions());
    expect(runtimeOptsOf().onReservedLeaves).toBeUndefined();
  });

  it("forwards the explicit liveAudio opt-in to the runtime", () => {
    mount(baseOptions({ liveAudio: true }));
    expect(runtimeOptsOf().liveAudio).toBe(true);
  });
});

describe("capture source resolution (screen/window/app compatibility path)", () => {
  it("passes desktop-capture IDs through for media.app (legacy capture global API)", async () => {
    (globalThis as Record<string, unknown>)[CAPTURE_GLOBAL] = {
      "app-window-id": { captureSourceId: "desktop-capture-id" },
    };

    mount(baseOptions());

    const resolver = runtimeOptsOf().resolveCaptureDevice as (
      deviceRef: string,
      sourceKind: string,
    ) =>
      | { captureSourceId?: string; deviceId?: string }
      | null
      | Promise<{ captureSourceId?: string; deviceId?: string } | null>;
    expect(typeof resolver).toBe("function");

    const result = await Promise.resolve(
      resolver("app-window-id", "media.app"),
    );
    expect(result).toEqual({ captureSourceId: "desktop-capture-id" });
  });

  it("keeps cam/mic behavior on missing source-id for media.app (placeholder)", async () => {
    (globalThis as Record<string, unknown>)[CAPTURE_GLOBAL] = {
      "app-window-id": { captureSourceId: "" },
    };

    mount(baseOptions());

    const resolver = runtimeOptsOf().resolveCaptureDevice as (
      deviceRef: string,
      sourceKind: string,
    ) =>
      | { captureSourceId?: string; deviceId?: string }
      | null
      | Promise<{ captureSourceId?: string; deviceId?: string } | null>;
    expect(
      await Promise.resolve(resolver("app-window-id", "media.app")),
    ).toBeNull();
  });
});
