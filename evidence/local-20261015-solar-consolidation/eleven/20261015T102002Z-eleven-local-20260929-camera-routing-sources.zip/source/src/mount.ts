// Solar's public mount() — a thin adapter over @lumencast/runtime.
//
// Since ADR 007 (Lumencast convergence, sub-chantier B), Solar no longer
// carries its own render tree, LSDP transport or leaf-grain state. Those
// were duplicates of what `@lumencast/runtime` already ships to spec
// (LSML 1.1 render + LSDP/1.1 wire). Solar's reason to exist is now the
// Zab-facing contract : a stable `mount()` + `SolarError` taxonomy the
// three hosts (Pulsar CEF / Prism webview / editor preview) depend on,
// mapped onto the runtime's `mount()`.
//
// Contract mapping (Solar → runtime) :
//   - `orionUrl`            → `serverUrl`   (Zab keeps the Orion-named field)
//   - `token` (SolarToken)  → `token`       (structurally identical)
//   - `mode`                → `mode`        (same broadcast/control/test union)
//   - `testSession`/`scene` → idem          (only meaningful in test mode)
//   - `onStatus`            → `onStatus`    (identical disconnected/connecting/live)
//   - `onError`             → `onError`     (LumencastError ≡ SolarError ; the
//                                            protocol ErrorCode union is byte-
//                                            equal to SolarErrorCode)
//   - return SolarHandle    ← LumencastHandle ({ disconnect, setToken } same shape)
//
// The runtime owns the lifecycle (subscribe → snapshot → bundle fetch →
// delta → scene_changed → crossfade → token rotation → teardown). Solar
// validates options up-front (host-friendly errors with the `solar.mount:`
// prefix the hosts assert on) and delegates.

import {
  createPeerViewerFromInjection,
  mount as mountRuntime,
} from "@lumencast/runtime";
import type {
  LumencastError,
  LumencastStatus,
  MountOptions as RuntimeMountOptions,
  ResolvePeerStream,
  SubscribePeerStream,
} from "@lumencast/runtime";
import { orionBundleUrl } from "./internal/orion-bundle-url";
import { installLiveVideoAutoplay } from "./internal/live-video-autoplay";
import {
  publisherOfferViewerInjection,
  readPeerViewerChannel,
  readPeerViewerInjection,
  ZAB_PEER_VIEWER_GLOBAL,
} from "./peer-viewer/injection";
import { createAntenneController } from "./peer-viewer/antenne-controller";
import { createSlotBindingRegistry } from "./peer-viewer/slot-binding";
import { validateOptions } from "./internal/validate-options";
import {
  createRenderAssetWebSocket,
  createLocalRenderAssetRegistry,
  readRenderAssetEndpoint,
} from "./internal/render-asset-wire";
import {
  createEditablePreviewWebSocket,
  editablePreviewFastPathEnabled,
  installEditablePreviewSideband,
  readEditablePreviewSidebandUrl,
} from "./internal/editable-preview-fast-path";
import type {
  MountOptions,
  ResolveCaptureDevice,
  SolarError,
  SolarHandle,
  SolarStatus,
} from "./types";

// Contract with the Prism preview host : the scene-server's bootstrap script
// pins a `deviceRef → deviceId` map on the page before Solar mounts. ACQUIRE
// (the capture-capable webview) reads it to map a bundle's LOGICAL deviceRef
// onto a physical Electron media device. The name is shared verbatim with
// Prism's `injectBootstrap` (scene-server.ts) — change it in BOTH places.
const ZAB_CAPTURE_DEVICES_GLOBAL = "__ZAB_CAPTURE_DEVICES__";
const ZAB_CAPTURE_DEFAULT_SCREEN_GLOBAL = "__ZAB_CAPTURE_DEFAULT_SCREEN__";

// One host-injected entry: a PORTABLE label + the picker-origin deviceId (NOT
// reusable here) for cams, or an origin-independent captureSourceId for screens.
interface ZabCaptureEntry {
  label?: string;
  deviceId?: string;
  captureSourceId?: string;
  kind?: string;
}

// Per-origin label → deviceId, resolved ONCE and shared across capture nodes.
// getUserMedia deviceIds are salted per origin/partition, so the picker-origin
// id is useless in this webview; the LABEL is the portable key. enumerateDevices
// only exposes labels after a getUserMedia grant in THIS origin, so we warm one
// up first (auto-granted in the preview webview), best-effort.
let originLabelMapPromise: Promise<Record<string, string>> | null = null;

/**
 * The embedded Prism host and the standalone Antenne both use the same
 * receive-only viewer glue, but only the embedded host is guaranteed to have
 * the Meet publishers on the local network.  Keep the historical relay-only
 * policy for a genuinely remote host while allowing local candidates for the
 * loopback Orion runtime.  This is a WebRTC transport choice only; it does not
 * alter the LSDP wire, scene graph, Pulsar, or lane ownership.
 */
function isLocalOrionUrl(orionUrl: string): boolean {
  try {
    const parsed = new URL(orionUrl);
    return /^(127\.0\.0\.1|localhost|\[::1\]|::1)$/i.test(parsed.hostname);
  } catch {
    return false;
  }
}

function originLabelMap(): Promise<Record<string, string>> {
  if (originLabelMapPromise !== null) return originLabelMapPromise;
  originLabelMapPromise = (async () => {
    const md =
      typeof navigator !== "undefined" ? navigator.mediaDevices : undefined;
    if (md?.enumerateDevices === undefined) return {};
    try {
      if (md.getUserMedia !== undefined) {
        const warm = await md.getUserMedia({ video: true });
        for (const t of warm.getTracks()) t.stop();
      }
    } catch {
      /* permission denied → labels stay blank, resolve to {} (PLACEHOLDER) */
    }
    const out: Record<string, string> = {};
    try {
      for (const d of await md.enumerateDevices()) {
        if (d.label.length > 0) out[d.label] = d.deviceId;
      }
    } catch {
      /* best-effort */
    }
    return out;
  })();
  return originLabelMapPromise;
}

// Default resolver (ADR 004 §A1.3, async per 2026-06-27 amendment). A declared
// deviceRef with no resolvable device → `null`. The runtime remains fail-closed
// for cameras, apps, and windows; media.screen alone may use the host's explicit
// machine-local display mapping, which Prism resolves before serving the page.
// If that mapping is unavailable, return null and keep the declared screen
// fail-closed: a cold scene must never open a native display picker or bind an
// arbitrary surface. The runtime AWAITS this, so there is no race against a
// late global mutation.
const captureDeviceResolver: ResolveCaptureDevice = async (
  deviceRef,
  sourceKind,
) => {
  const map = (
    globalThis as {
      [ZAB_CAPTURE_DEVICES_GLOBAL]?: Record<string, ZabCaptureEntry>;
    }
  )[ZAB_CAPTURE_DEVICES_GLOBAL];
  const entry = map?.[deviceRef];
  let defaultScreen = (
    globalThis as {
      [ZAB_CAPTURE_DEFAULT_SCREEN_GLOBAL]?: ZabCaptureEntry | null;
    }
  )[ZAB_CAPTURE_DEFAULT_SCREEN_GLOBAL];
  // Screen/window/app: a desktopCapturer source id is origin-independent →
  // verbatim. `media.app` (RFC-0001 Amendment 3) resolves the SAME shape —
  // Prism's page-global injection re-resolves it fresh (against the
  // currently open windows, by app name) on every serve, so by the time it
  // reaches here it is just another desktopCapturer id, exactly like a
  // picked window.
  if (
    sourceKind === "media.screen" ||
    sourceKind === "media.window" ||
    sourceKind === "media.app"
  ) {
    if (
      sourceKind === "media.screen" &&
      !entry?.captureSourceId &&
      !defaultScreen?.captureSourceId
    ) {
      const resolveDefault = (
        globalThis as {
          __ZAB_CAPTURE_RESOLVE_DEFAULT_SCREEN__?: () => Promise<ZabCaptureEntry | null>;
        }
      ).__ZAB_CAPTURE_RESOLVE_DEFAULT_SCREEN__;
      if (typeof resolveDefault === "function")
        defaultScreen = await resolveDefault();
    }
    const captureSourceId =
      entry?.captureSourceId ??
      (sourceKind === "media.screen"
        ? defaultScreen?.captureSourceId
        : undefined);
    return captureSourceId !== undefined && captureSourceId !== ""
      ? { captureSourceId }
      : null;
  }
  if (entry === undefined) {
    return null;
  }
  // Cam/mic: re-resolve the PORTABLE label against this origin's devices. No
  // label / no match → null → PLACEHOLDER, never the wrong default cam.
  if (entry.label === undefined || entry.label === "") {
    return null;
  }
  const byLabel = await originLabelMap();
  const local = byLabel[entry.label];
  return local !== undefined ? { deviceId: local } : null;
};

// The peer-viewer injection sources (preview `__ZAB_PEER_VIEWER__` + antenne
// LSDP `__ZAB_LSDP_PEER_VIEWER__`) and the slotRef re-keying registry live in
// `./peer-viewer/*` (ADR Blue 009 §3.2–3.3). `mount()` reads both sources, joins
// every pinned room as a VIEWER (no capture), and feeds the runtime the peer
// streams keyed by `peer_label`. On the antenne, slot→peer assignments re-key
// `x-zab.meet-peer` nodes by `slotRef` ; on the preview path nothing changes.

export function mount(options: MountOptions): SolarHandle {
  // Host-friendly validation with Solar's own message prefix. The runtime
  // validates too, but its messages say "Lumencast" — hosts assert on
  // "solar.mount:".
  validateOptions(options);
  const localOrion = isLocalOrionUrl(options.orionUrl);

  // ADR 006 #3 / ADR Blue 009 §3.2–3.3 — bridge receive-only Meet peer streams
  // into the runtime's LIVE `media` / `x-zab.meet-peer` primitives. The viewer
  // OWNS the peer connections + track lifecycle ; the primitive is a pure
  // consumer (RC-ReadOnly : never mutates the scene ; RC-Geo enforced inside the
  // primitive — the stream fills the node's box). Two activation paths :
  //
  //   PRISM LOCAL SOLAR (Preview + local live browser_source) — the
  //     scene-server pins `__ZAB_PEER_VIEWER__` BEFORE mount and may also expose
  //     the loopback room-reconciliation channel. Read synchronously, join
  //     every room, and apply channel snapshots to the already-mounted viewer.
  //     The reserved-leaf hook is NOT registered (these pages carry no
  //     `__cam.*` projection).
  //
  //   ANTENNE (Pulsar CEF) — there is no Prism : the viewer creds + slot→peer
  //     projection arrive ASYNC on Orion's LSDP, surfaced by the runtime
  //     (≥ 0.11.0) via `onReservedLeaves`. A slot-aware controller is threaded at
  //     mount and armed by the hook (`leaves.viewer` → join receive-only ;
  //     `leaves.slots` → re-key `x-zab.meet-peer` nodes by `slotRef`). The legacy
  //     `__ZAB_LSDP_PEER_VIEWER__` global (#29) still arms it synchronously for
  //     back-compat.
  const {
    injection: peerViewerInjection,
    slotBindings,
    fromLsdp,
    fromPrism,
  } = readPeerViewerInjection();
  const disablePeerViewer =
    (globalThis as { __ZAB_DISABLE_PEER_VIEWER__?: unknown })
      .__ZAB_DISABLE_PEER_VIEWER__ === true;
  // A local Prism browser_source is still a Prism-owned Solar document even
  // when the vendored runtime has also exposed an LSDP reserved-leaf global.
  // Prefer the same page-global/channel path as Preview in that case.  The
  // previous `!fromLsdp` gate let a stale or auxiliary LSDP leaf divert the
  // live document into the Antenne controller, so Preview received the rooms
  // while the Program browser_source did not.  Remote/standalone hosts keep
  // the Antenne branch exactly as before.
  const peerViewerChannel = readPeerViewerChannel();
  const usePrismLocalViewer =
    (localOrion && (fromPrism || peerViewerChannel !== null)) ||
    (!fromLsdp && (peerViewerInjection !== null || peerViewerChannel !== null));
  let resolvePeerStream: ResolvePeerStream;
  let subscribePeerStream: SubscribePeerStream;
  let onReservedLeaves: RuntimeMountOptions["onReservedLeaves"];
  let teardownPeerViewer: () => void;

  const surfaceJoinError = (err: unknown): void => {
    options.onError?.({
      code: "INTERNAL",
      message: `peer-viewer join failed: ${
        err instanceof Error ? err.message : String(err)
      }`,
      recoverable: true,
    });
  };

  if (disablePeerViewer) {
    resolvePeerStream = () => null;
    subscribePeerStream = (_key, listener) => {
      listener(null);
      return () => undefined;
    };
    teardownPeerViewer = () => undefined;
  } else if (usePrismLocalViewer) {
    // PRISM LOCAL SOLAR — join EVERY pinned room and thread the viewer's RAW resolvers
    // (first-connected-wins aggregation, `peer_label`-keyed). A `meet.peer` node
    // that mounts before its peer connects shows a stream-less box and re-renders
    // via `subscribePeerStream` on arrival. A join failure must not take the
    // scene down — surface it through `onError` and let the rest render.
    const peerViewer = createPeerViewerFromInjection(
      // Both Preview and the local Program browser_source run in Prism's
      // loopback Electron host. Keep relay candidates when configured, but
      // also allow a local host candidate so either return remains useful
      // without a coturn process.
      publisherOfferViewerInjection(peerViewerInjection ?? { rooms: [] }, {
        iceTransportPolicy: "all",
      }),
    );
    void peerViewer.join().catch(surfaceJoinError);
    // Slot-aware on the PREVIEW too (parity with the antenne): wrap the raw
    // `peer_label`-keyed registry with the slot-binding so an `x-zab.meet-peer`
    // node keyed by a positional `@<n>` (auto-fill in arrival order) or a slotRef
    // resolves. A bare `peer_label` passes straight through — a strict superset of
    // the prior raw wiring. Without this the preview resolved `@0` as a LITERAL
    // label → no peer → empty slot, even with the stream received (positional was
    // ANTENNE-only). The registry's `subscribeRoster` drives the re-resolve on a
    // peer connect/leave so a late arrival fills the slot.
    // Prism pins the authored slot snapshot alongside the room credentials.
    // Use it here instead of rebuilding camera identity from WebRTC arrival
    // order. Arrival order is only the fallback for genuinely positional
    // scenes; when `@0`/`@1`/`@2` are explicitly mapped, each React consumer
    // subscribes to its exact peer before that peer's first track arrives.
    // This also prevents three near-simultaneous joins from leaving one slot
    // behind as a transparent placeholder while the registry already holds
    // all three streams.
    const slots = createSlotBindingRegistry(peerViewer.registry, slotBindings);
    let currentSlotBindings: Record<string, string> = { ...slotBindings };
    let channelSocket: WebSocket | null = null;
    let channelRetry: ReturnType<typeof setTimeout> | null = null;
    let channelStopped = false;
    let stateUpdates = Promise.resolve();
    let routingRevision: number | null = null;
    const routingObservers = new Map<string, () => void>();
    const reportRouting = (): void => {
      if (
        channelSocket?.readyState !== 1 ||
        typeof channelSocket.send !== "function" ||
        routingRevision === null
      )
        return;
      const observed = Object.fromEntries(
        [...routingObservers.keys()].map((ref) => [
          ref,
          {
            peerLabel: slots.resolvedPeer(ref),
            available: slots.resolve(ref) !== null,
          },
        ]),
      );
      try {
        channelSocket.send(
          JSON.stringify({
            type: "peer_viewer_routing",
            revision: routingRevision,
            slots: observed,
          }),
        );
      } catch {
        // A closing diagnostic channel must never interrupt camera delivery.
      }
    };
    const observeRouting = (state: {
      slotRefs?: unknown;
      routingRevision?: unknown;
    }): void => {
      routingRevision =
        typeof state.routingRevision === "number"
          ? state.routingRevision
          : null;
      const refs = Array.isArray(state.slotRefs)
        ? state.slotRefs
            .filter(
              (ref): ref is string =>
                typeof ref === "string" &&
                /^(?:@\d+|[a-z][a-z0-9-]{0,63})$/.test(ref),
            )
            .slice(0, 256)
        : [];
      for (const [ref, off] of routingObservers)
        if (!refs.includes(ref)) {
          off();
          routingObservers.delete(ref);
        }
      for (const ref of refs)
        if (!routingObservers.has(ref)) {
          routingObservers.set(ref, () => undefined);
          routingObservers.set(ref, slots.subscribe(ref, reportRouting));
        }
      reportRouting();
    };

    const applyPeerViewerState = async (state: unknown): Promise<void> => {
      if (typeof state !== "object" || state === null) return;
      const candidate = state as {
        rooms?: unknown;
        slots?: unknown;
        slotRefs?: unknown;
        routingRevision?: unknown;
      };
      if (!Array.isArray(candidate.rooms)) return;
      // Keep the diagnostic global truthful for the already-mounted page. The
      // normaliser below still validates every room before it reaches Meet.
      (globalThis as Record<string, unknown>)[ZAB_PEER_VIEWER_GLOBAL] = state;
      const resolved = readPeerViewerInjection();
      const rooms =
        resolved.injection !== null && "rooms" in resolved.injection
          ? resolved.injection.rooms
          : [];
      // The local multi-room runtime fingerprints credentials and performs an
      // add-first receive-side handoff even when Meet keeps the same opaque
      // room id. Do not call `leave()` here: that would tear down both local
      // consumers before the replacement socket has delivered its first track.
      // The runtime owns the actual replacement lifecycle.
      await peerViewer.setRooms(rooms);
      for (const slotRef of Object.keys(currentSlotBindings)) {
        if (!(slotRef in resolved.slotBindings)) slots.assign(slotRef, null);
      }
      for (const [slotRef, peerLabel] of Object.entries(
        resolved.slotBindings,
      )) {
        slots.assign(slotRef, peerLabel);
      }
      currentSlotBindings = { ...resolved.slotBindings };
      observeRouting(candidate);
    };

    const connectPeerViewerChannel = (): void => {
      if (
        channelStopped ||
        peerViewerChannel === null ||
        typeof globalThis.WebSocket !== "function"
      )
        return;
      const socket = new globalThis.WebSocket(peerViewerChannel.url);
      channelSocket = socket;
      socket.addEventListener("open", reportRouting);
      socket.addEventListener("message", (event) => {
        try {
          const frame = JSON.parse(String(event.data)) as {
            type?: unknown;
            state?: unknown;
          };
          if (frame.type !== "peer_viewer") return;
          stateUpdates = stateUpdates
            .then(() => applyPeerViewerState(frame.state))
            .catch(surfaceJoinError);
        } catch {
          // Ignore malformed local control frames; the initial room snapshot
          // remains active and the channel will continue to receive updates.
        }
      });
      socket.addEventListener("close", () => {
        if (channelSocket === socket) channelSocket = null;
        if (channelStopped || channelRetry !== null) return;
        channelRetry = setTimeout(() => {
          channelRetry = null;
          connectPeerViewerChannel();
        }, 250);
      });
      socket.addEventListener("error", () => {
        // The close event schedules the bounded reconnect. No error is allowed
        // to surface into the render path or blank the scene.
      });
    };
    connectPeerViewerChannel();
    observeRouting(
      ((globalThis as Record<string, unknown>)[ZAB_PEER_VIEWER_GLOBAL] ??
        {}) as { slotRefs?: unknown; routingRevision?: unknown },
    );

    const e2eDiagnostics = (
      globalThis as {
        __PRISM_SOLAR_DIAG__?: {
          peerRegistrySnapshot?: () => unknown;
        };
      }
    ).__PRISM_SOLAR_DIAG__;
    if (e2eDiagnostics !== undefined) {
      e2eDiagnostics.peerRegistrySnapshot = () => ({
        labels: peerViewer.registry.orderedLabels(),
        slots: Object.fromEntries(
          Object.keys(currentSlotBindings).map((key) => [
            key,
            {
              peer: slots.boundPeer(key),
              resolved: slots.resolve(key) !== null,
            },
          ]),
        ),
      });
    }
    resolvePeerStream = (key) => slots.resolve(key);
    subscribePeerStream = (key, listener) => slots.subscribe(key, listener);
    const onBeforeUnload = (): void => {
      for (const off of routingObservers.values()) off();
      routingObservers.clear();
      channelStopped = true;
      if (channelRetry !== null) clearTimeout(channelRetry);
      channelRetry = null;
      channelSocket?.close();
      channelSocket = null;
      peerViewer.leave();
    };
    window.addEventListener("beforeunload", onBeforeUnload);
    teardownPeerViewer = () => {
      window.removeEventListener("beforeunload", onBeforeUnload);
      onBeforeUnload();
    };
  } else {
    // ANTENNE — slot-aware controller threaded now, armed by the runtime hook
    // (and synchronously by a mount-time `__ZAB_LSDP_PEER_VIEWER__` global, #29).
    // `x-zab.meet-peer` nodes resolve through it ; a bare `peer_label` passes
    // straight through, so this is a strict superset of the `meet.peer` path.
    const controller = createAntenneController({
      createViewer: (injection) =>
        createPeerViewerFromInjection(
          publisherOfferViewerInjection(
            injection,
            localOrion ? { iceTransportPolicy: "all" } : {},
          ),
        ),
      onJoinError: surfaceJoinError,
    });
    if (peerViewerInjection !== null) {
      // Back-compat : a mount-time LSDP global already carries the antenne creds
      // (+ slot snapshot) — arm the controller exactly as the hook would.
      controller.applyReservedLeaves({
        viewer: publisherOfferViewerInjection(peerViewerInjection),
        slots: slotBindings,
      });
    }
    resolvePeerStream = controller.resolvePeerStream;
    subscribePeerStream = controller.subscribePeerStream;
    onReservedLeaves = (leaves) => controller.applyReservedLeaves(leaves);
    teardownPeerViewer = () => controller.leave();
  }

  const renderAssetEndpoint = readRenderAssetEndpoint();
  // An older Lumencast release rejects blob: at the render gate. Keep its
  // existing data: hydration unless both sides advertise this capability.
  const supportsHostAssetUrls =
    (mountRuntime as typeof mountRuntime & { supportsHostAssetUrls?: boolean })
      .supportsHostAssetUrls === true;
  const localAssetRegistry =
    renderAssetEndpoint !== null && supportsHostAssetUrls
      ? createLocalRenderAssetRegistry()
      : null;
  const renderAssetWebSocket =
    renderAssetEndpoint === null
      ? undefined
      : createRenderAssetWebSocket(
          renderAssetEndpoint,
          globalThis.WebSocket,
          localAssetRegistry ?? undefined,
        );
  const editableSidebandUrl = readEditablePreviewSidebandUrl();
  const webSocketImpl =
    editablePreviewFastPathEnabled() && editableSidebandUrl === null
      ? createEditablePreviewWebSocket(
          renderAssetWebSocket ?? globalThis.WebSocket,
        )
      : renderAssetWebSocket;

  const runtimeOptions: RuntimeMountOptions = {
    target: options.target,
    serverUrl: options.orionUrl,
    token: options.token,
    ...(localAssetRegistry !== null
      ? { isHostAssetUrl: localAssetRegistry.isHostAssetUrl }
      : {}),
    mode: options.mode,
    ...(options.sceneTransition !== undefined
      ? { sceneTransition: options.sceneTransition }
      : {}),
    ...(options.onSceneCommit !== undefined
      ? { onSceneCommit: options.onSceneCommit }
      : {}),
    ...(webSocketImpl !== undefined ? { webSocketImpl } : {}),
    // The embedded local Orion runtime serves the bundle at
    // `/orion/api/v1/scenes/{id}/render-bundle?v={hash}`, not the runtime's
    // default host-root LSDP layout. Derive the local bundle URL from the WS
    // `orionUrl` so the runtime fetches the right artefact.
    resolveBundleUrl:
      options.resolveBundleUrl ?? orionBundleUrl(options.orionUrl),
    ...(options.testSession !== undefined
      ? { testSession: options.testSession }
      : {}),
    ...(options.scene !== undefined ? { scene: options.scene } : {}),
    ...(options.preloadRoster !== undefined && options.preloadRoster.length > 0
      ? { preloadRoster: options.preloadRoster }
      : {}),
    ...(options.preloadRosterImages === true
      ? { preloadRosterImages: true }
      : {}),
    ...(options.onStatus
      ? {
          onStatus: (status: LumencastStatus): void =>
            options.onStatus?.(toSolarStatus(status)),
        }
      : {}),
    ...(options.onError
      ? {
          onError: (err: LumencastError): void =>
            options.onError?.(toSolarError(err)),
        }
      : {}),
    // The broadcast CEF is rendered into Pulsar's atlas. Native Pulsar owns
    // the OBS Virtual Camera capture in that path; allowing Solar's browser
    // context to call getUserMedia as well creates a second dshow consumer and
    // can make the on-air camera flat/black. Return null so the runtime emits
    // its transparent placeholder and the native `ZabCapture:*` item remains
    // the sole camera consumer. Control/editor mounts keep the host resolver
    // and therefore retain live local camera acquisition.
    resolveCaptureDevice:
      options.mode === "broadcast" && options.captureInBrowser !== true
        ? async (deviceRef, sourceKind) => {
            // Pulsar owns local camera inputs on the broadcast path, but
            // desktop/window/app captures remain a supported Solar contract.
            // Keep those IDs flowing through unchanged (the existing
            // media.app/window resolver tests depend on this distinction).
            if (
              sourceKind === "media.camera" ||
              sourceKind === "media.webcam"
            ) {
              return null;
            }
            return (options.resolveCaptureDevice ?? captureDeviceResolver)(
              deviceRef,
              sourceKind,
            );
          }
        : (options.resolveCaptureDevice ?? captureDeviceResolver),
    // ADR 006 #4 — when a viewer is active, thread its peer-stream resolvers so
    // LIVE `media` nodes render the matching peer's MediaStream in `srcObject`.
    // On the antenne these are slotRef-aware (ADR Blue 009 §3.3).
    resolvePeerStream,
    subscribePeerStream,
    // ADR Blue 009 §3.2–3.3 — on the antenne the runtime surfaces the reserved
    // `__cam.*` LSDP leaves here (full projection on every change). The controller
    // arms the receive-only viewer from `leaves.viewer` and re-keys
    // `x-zab.meet-peer` nodes from `leaves.slots`. Not registered on the preview
    // path (Prism carries no `__cam.*` projection).
    ...(onReservedLeaves !== undefined ? { onReservedLeaves } : {}),
    // Un-mute live guest-peer audio into the page mix (Pulsar/OBS browser_source
    // captures page audio) — runtime `@lumencast/runtime` ≥ 0.13.0. Forwarded
    // verbatim; ABSENT from the runtime options when the host omits it, so muted
    // stays the byte-identical default for every non-opt-in consumer. Only the
    // served host bundle sets it, and only for the diffused/recorded modes.
    ...(options.liveAudio !== undefined
      ? { liveAudio: options.liveAudio }
      : {}),
    ...(options.realtimeDeltas !== undefined
      ? { realtimeDeltas: options.realtimeDeltas }
      : {}),
    // ADR 013 Prism §3.1 (issue #41) — a one-shot render-tree transform the
    // runtime applies ONCE per loaded bundle (the atlas z-band split, wired
    // from `?atlas=` by the host entries). Forwarded verbatim; ABSENT from the
    // runtime options entirely when the host omits it, so the default render
    // path stays byte-identical (strict non-regression).
    ...(options.transformRoot !== undefined
      ? { transformRoot: options.transformRoot }
      : {}),
  };

  const handle = mountRuntime(runtimeOptions);
  const teardownEditableSideband =
    editableSidebandUrl === null
      ? () => undefined
      : installEditablePreviewSideband(editableSidebandUrl);
  const teardownLiveVideoAutoplay = installLiveVideoAutoplay(
    options.liveAudio === true,
  );

  return {
    disconnect: () => {
      teardownEditableSideband();
      teardownLiveVideoAutoplay();
      // Tear the viewer down with the scene : leave the room and drop the peer
      // connections (the viewer owns them) so a webview reload doesn't leak a
      // ghost peer into the mesh.
      teardownPeerViewer();
      handle.disconnect();
      localAssetRegistry?.dispose();
    },
    setToken: (token) => handle.setToken(token),
  };
}

/**
 * The runtime creates the live video element before the WebRTC stream arrives
 * and assigns `srcObject` later. Chromium does not reliably re-run the
 * declarative `autoPlay` path for that late assignment, especially in a
 * hidden CEF/webview host. Start playback imperatively once metadata or a
 * playable frame exists; muting first keeps the operation gesture-free.
 */
// --- contract mapping helpers -----------------------------------------

// The two status unions are identical ("disconnected" | "connecting" |
// "live") ; this keeps the boundary explicit and would fail to compile if
// either side drifted.
function toSolarStatus(status: LumencastStatus): SolarStatus {
  return status;
}

// `LumencastError` and `SolarError` are structurally identical and the
// protocol `ErrorCode` union is byte-equal to `SolarErrorCode`, so the
// forward is lossless. The explicit object construction documents the
// contract boundary and pins it at compile time.
function toSolarError(err: LumencastError): SolarError {
  return {
    code: err.code,
    message: err.message,
    recoverable: err.recoverable,
  };
}
