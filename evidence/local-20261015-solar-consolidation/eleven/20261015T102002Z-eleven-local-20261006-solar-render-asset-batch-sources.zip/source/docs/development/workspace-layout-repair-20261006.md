# Historical workspace layout repair

Owner: Eleven. Authority: `Fixe les anomalies historiques` (2026-10-06).

The [routing inventory](../../evidence/local-20261006-workspace-layout-repair/eleven/20261006T091018Z-evidence-routing.json) maps every affected original evidence path to its current direct record or archive entry, with SHA-256 and original metadata. Direct records preserve exact bytes. Archive bundles include the complete historical unit layout, including its already compliant records, so fixture and media relationships are retained. Only the inventoried non-compliant loose files were removed after archive verification; signed Git history was preserved.

To verify a bundle, run `python D:/Documents/Zab/agents/_shared/restore-historical-evidence.py evidence/local-20261006-workspace-layout-repair/eleven/20261006T091018Z-evidence-routing.json` from this worktree. Add `--extract-to .cache/historical-evidence-<unique-run>` to reconstruct the archived relative paths into a fresh cache. Existing output files are never overwritten. Historical receipts describe the original run; extraction does not constitute a new runtime validation.

Current consumers remain direct file references and were repaired with preserved source bytes. Worktree old/new paths and branches are recorded in the repository-level repair evidence. The active Prism Demo path and HEAD were preserved.
