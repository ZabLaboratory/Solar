# Cache de sources immuables

Propriétaires : src/scenes/cache.ts, startup.ts et browser-store.ts ; stockage
Node : src/server/scene-store.ts ; démarrage servi : src/host-entry.ts.

createCachedSceneSourceProvider compose un fournisseur Canvas et SceneSourceStore.
Une requête sans version découvre la révision sur Canvas. Une requête exacte
utilise la capsule locale vérifiée, sans réseau ; un miss acquiert puis conserve
la source publiée. Une capsule corrompue échoue explicitement sans changer de scène.

La capsule solar.scene-cache.v1 conserve les octets LSMLZ, ou LSML et assets,
ainsi que le manifeste Blue complet. Chaque lecture revalide l'adresse LSML,
le digest des octets source/transport, les assets hashés et la fermeture Blue.
offline_ready et binding_closure_complete doivent être vrais. Modifier le LSML
sans changer son adresse est refusé même si son digest d'octets est recalculé.

FileSceneSourceStore publie une seule fois par staging/link atomique dans le même
dossier. Une publication concurrente identique est idempotente ; un contenu
différent refuse SOURCE_CACHE_KEY_CONFLICT et préserve la capsule acceptée.
Les clés sont SHA-256(id, version, format), jamais un chemin utilisateur.
Les tailles d'archive, d'assets et les expansions ZIP sont bornées.

```ts
// Hôte Node/Electron ; transférer les sources à la frontière de rendu existante.
import { FileSceneSourceStore, createCachedSceneSourceProvider } from "@zablab/solar/server";
const provider = createCachedSceneSourceProvider(canvasProvider,
  new FileSceneSourceStore(accountOwnedSourceDirectory));
const scene = await provider.get(sceneId, { sceneVersion, format: "lsmlz" });
```

Le launcher Prism synchronise toutes les pages du catalogue accessible (`mine=false`)
avant admission du studio. `SceneSourceLibrary` partitionne les fichiers par gateway
et identit� stable de compte. Elle ne relit pas un index disque comme autorisation :
chaque lancement v�rifie le catalogue et les descripteurs aupr�s de Canvas.
Les archives inchang�es sont relues localement ; une nouvelle r�vision est t�l�charg�e,
puis l'index est publi� atomiquement et les anciennes capsules sont retir�es.
Les sc�nes �ditables restent aliment�es par LSDP ; une sc�ne standard non publi�e
est compt�e sans pr�tendre disposer d'une source publi�e.

Le host re�oit `sceneSourcesUrl` de Prism et compose `createLocalSceneSourceProvider`
avec son fournisseur Canvas. Une lecture exacte locale revalide la capsule ; un 404
retombe sur l'acquisition autoris�e. Corruption, version incoh�rente et refus d'acc�s
�chouent explicitement. Les URLs HTTP du LSML restent des URLs ; seules les ressources
embarqu�es dans LSMLZ sont pr�par�es localement. Les mutations ne modifient pas le cache.
Prism v�rifie ensuite les r�visions toutes les 60 secondes, sans transfert concurrent
de deux passes. Logout/changement de compte annule les requ�tes et r�voque les lectures.
Une panne r�seau p�riodique garde le dernier catalogue autoris� jusqu'au prochain essai.

BrowserSceneSourceStore reste une surface optionnelle distincte, avec sa limite de
64 entr�es/512 MiB. Le launcher utilise FileSceneSourceStore, sans plafond de 64 sc�nes.
Le cache n'autorise pas Blue : Orion conserve l'admission des programmes sign�s.

L'adresse source `scene_version` est distincte du `artifact_set_digest` admis
par Orion. Les documents Solar natifs conservent la première et portent la
seconde sous `x-orion-artifact-set`. Le manifeste Blue porte l'adresse source ;
le catalogue Orion conserve le programme signé et les déclarations associées.

`scripts/prove-cold-start-cef.py` exerce FileSceneSourceStore et le catalogue
Orion après arrêt complet des processus : deux nouvelles instances CEF reprennent
Program/Preview, source/assets/déclarations inchangés, mutations live abandonnées.
Le harnais sert le cache Node vérifié aux CEF si nécessaire. Il ne certifie pas
la persistance IndexedDB entre processus. Sans `--capsule`, le manifeste et les
signatures sont des fixtures de contrat explicitement déclarées. Avec
`--capsule`, il consomme le résultat HTTP/SQL réellement validé et signé par le
Canvas local, qui a utilisé l'identité ZabAuth et la Blue publiée via ZabGate.
La clé reste locale au producteur ; ce n'est pas un déploiement Canvas distant.
`scripts/prove-authenticated-canvas.mjs` qualifie séparément login, référence
signée réelle et acquisition source LSMLZ/LSML. Le locator broker-only refuse le
bearer opérateur comme prévu ; sa récupération mTLS est une preuve séparée.
Voir [maturité et certificat](maturity.md).

Tests : scene-cache.test.ts, scene-store.test.ts, startup-cache.test.ts. check:source-usage couvre les
modules accessibles depuis les quatre entrées ; tsc/eslint couvrent les symboles.
Cette analyse ne promet pas de détecter tous les usages externes/dynamiques.
